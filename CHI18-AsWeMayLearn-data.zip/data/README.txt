The contents of this archive: 

chi17_dataset_anon_2017-09-19.sql.zip -- dataset used for reporting in the paper
chi17_dataset_query_examples.md -- examples of queries that can be run on the dataset
user-evaluation--complete-answers.htm -- the user feedback
teacher-interview.txt -- an interview with the teacher of the class about the usage of the system in his class
feedback-to-the-teacher.txt -- feedback that the students provided to the teacher about the system
